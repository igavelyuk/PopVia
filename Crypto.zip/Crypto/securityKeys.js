// test file
module.exports = {
privateKey:'abc8611f89f897da6b3231c58e4813bd1a373ba3f1719a9cc139e4b5d0dc9f48',
sendAddr:'', // 'n23iqtgwjkdxy5SfRBHFdxtfiHBy3ioAJS'
receiveAddr:'mzHND2txx6CVL2kicbS4Q1MQDKD71oeukr',
quantity:''
}
// module.exports=key;
